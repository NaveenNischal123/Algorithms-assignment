s = int(input("Enter the Side of a Square:-"))
area = s*s
perimeter = 4*s

print("The perimeter is {0} and area is {1} of a Square of side {2}" .format(perimeter, area, s))