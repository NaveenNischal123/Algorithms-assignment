def compound_interest(principle, rate, time): 
 
	Amount = principle * (pow((1 + rate / 100), time)) 
	CI = Amount - principle 
	print("The Compound Interest for priciple {0} rate {1} and time {2} is {3}" .format(principle, rate, time, CI)) 

p = int(input("Enter the principle:-"))
r = float(input("Enter the rate:-"))
t = int(input("Enter the time span:-"))
compound_interest(p, r, t) 

 
