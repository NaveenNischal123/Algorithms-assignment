
def Cel_To_Fah(n): 
	
	return (n*1.8)+32

n = 36.77
print(Cel_To_Fah(n)) 


