import os
import psutil 
import time
def fib(n):

    if n < 0:
        print("number entered is not valid")

    elif n == 0:     
        return 0 

    elif n == 1:
        return 1
    else:
        return fib(n-1)+fib(n-2) 

start = time.time()  

k = int(input("enter Fibonacci sequence index number: "))
print(fib(k))

process = psutil.Process(os.getpid())
print(process.memory_info().rss) 

end = time.time()
print(f"time taken: {end - start}")