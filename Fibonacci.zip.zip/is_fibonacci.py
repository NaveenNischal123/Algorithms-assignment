
import math 
import os
import psutil  

def isPerfectSquare(x): 
    s = int(math.sqrt(x)) 
    return s*s == x 
  
 
def isFibonacci(n): 
  
    return isPerfectSquare(5*n*n + 4) or isPerfectSquare(5*n*n - 4) 
     
n = int(input("enter the n.o to check :"))  
if (isFibonacci(n) == True): 
    print (n,"is a Fibonacci Number")
else: 
    print (n,"is a not Fibonacci Number ")

process = psutil.Process(os.getpid())
print(f"Total memory : {process.memory_info().rss}")